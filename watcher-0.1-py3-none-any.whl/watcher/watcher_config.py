config = {
    'logFile': '/tmp/watcher.log',
    'outputType': 'txt',
    'interval': 5,
    'workTime': 30,
}
